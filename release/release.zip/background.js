chrome.app.runtime.onLaunched.addListener(function() {
    window.open('index.html');
});